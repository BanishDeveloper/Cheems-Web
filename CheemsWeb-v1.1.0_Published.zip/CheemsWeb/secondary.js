function darkTheme(){
    title.style.color = "white"
    body.style.backgroundColor = "rgb(25,25,25)"
    search_bar.style.backgroundColor = "rgb(200,200,200)"
    search_bar.style.border = " 3.5px solid rgb(20, 126, 190)"
    document.getElementById("settings-page").style.backgroundColor = "rgb(25,25,25)"
  }
  function lightTheme(){
    title.style.color = "rgb(3, 3, 3)"
    body.style.backgroundColor = "rgb(220,220,220)"
    search_bar.style.backgroundColor = "white"
    search_bar.style.border = "3.5px solid rgb(9, 106, 170)"
    document.getElementById("settings-page").style.backgroundColor = "rgb(220,220,220)"
}
var is_dark = false
