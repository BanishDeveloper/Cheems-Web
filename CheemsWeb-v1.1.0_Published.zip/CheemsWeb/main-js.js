const search_bar = document.getElementById("search")
const search_bar_type = document.getElementById("search-text")
const title = document.getElementById("title-logo")
const body = document.body
const settings_page = document.getElementById("settings-page")
const main_page = document.getElementById("main-page")
var is_website = true
var type_of_search = "https://"
search_bar.addEventListener("keydown", e => {
 if (e.key == "Enter"){
     if(search_bar.value.length > 0){
         window.location.assign(type_of_search+search_bar.value)
        }
     }
   });
search_bar_type.onclick = function(){
  if(is_website){
    type_of_search = "http://www.google.com/search?q="
    search_bar_type.innerText = "Search Mode "+"Google"
    is_website = false
  }else{
    type_of_search = "https://"
    search_bar_type.innerText = "Search Mode "+"Website"
    is_website = true
  }
}
document.getElementById("press-to-search").onclick=function(){
  if(search_bar.value.length > 0){
    window.location.assign(type_of_search+search_bar.value)
   }
}

lightTheme()
document.getElementById("open-set").onclick = function(){
  document.title = "CHEEMS WEB SETTINGS"
  settings_page.style.display = "inline"
  main_page.style.display = "none"
}
document.getElementById("close-set").onclick = function(){
  document.title = "CHEEMS WEB"
  settings_page.style.display = "none"
  main_page.style.display = "inline"
}
document.getElementById("change-theme").onclick = function(){
  if(!is_dark){
    darkTheme()
    is_dark = true
  } else {
    lightTheme()
    is_dark = false
  }
}